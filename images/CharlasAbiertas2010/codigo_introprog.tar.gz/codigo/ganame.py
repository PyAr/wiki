ing = raw_input("Dame un nro: ")
nro = int(ing)
if nro > 10:
    print "Ganaste!"
else:
    ganador = nro + 1
    print "Te ganamos!", ganador
print "-"
