import random

def juega(nivel):
    oculto = random.randint(0, nivel)

    opciones = []

    while True:
        ing = raw_input("Nro! ")
        nro = int(ing)
        if nro == oculto:
            break
        else:
            opciones.append(nro)

        if nro < oculto:
            print "Te quedaste corto"
        else:
            print "Te pasaste"

    print "Adivinaste!"


ing = raw_input("Nivel? ")
niv = int(ing)
juega(niv)


