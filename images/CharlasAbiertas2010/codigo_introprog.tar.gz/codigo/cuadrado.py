# pedimos data al usuario y convertimos a nro
ingresado = raw_input("Ingrese un nro: ")
numero = int(ingresado)

# calculamos el cuadrado
cuadrado = numero ** 2

# devolvemos el resultado
print 'El resultado es:', cuadrado
