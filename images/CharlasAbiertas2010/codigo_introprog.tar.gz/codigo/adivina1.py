oculto = 42

# ing = raw_input("Nro! ")
# nro = int(ing)
#
# while nro != oculto:
#     ing = raw_input("Otro! ")
#     nro = int(img)

while True:
    ing = raw_input("Nro! ")
    nro = int(ing)
    if nro == oculto:
        break

print "Adivinaste!"






