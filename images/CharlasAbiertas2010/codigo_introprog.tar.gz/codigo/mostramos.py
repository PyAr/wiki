import random

oculto = random.randint(0, 20)

opciones = []

while True:
    ing = raw_input("Nro! ")
    nro = int(ing)
    if nro == oculto:
        break
    else:
        opciones.append(nro)

    if nro < oculto:
        print "Te quedaste corto"
    else:
        print "Te pasaste"

print "Adivinaste!"

for i, opcion in enumerate(opciones):
    print "Opcion", i, ":", opcion




