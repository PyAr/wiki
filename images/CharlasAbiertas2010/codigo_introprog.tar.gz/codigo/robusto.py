# pedimos data al usuario y convertimos a nro
ingresado = raw_input("Ingrese un nro: ")

try:
    numero = int(ingresado)
except ValueError:
    print "No era numero!"
else:
    # calculamos el cuadrado
    cuadrado = numero ** 2

    # devolvemos el resultado
    print 'El resultado es:', cuadrado
