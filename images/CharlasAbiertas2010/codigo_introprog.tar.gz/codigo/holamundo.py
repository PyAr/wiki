print "Hola mundo!"
