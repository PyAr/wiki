import random

oculto = random.randint(0, 20)

while True:
    ing = raw_input("Nro! ")
    nro = int(ing)
    if nro == oculto:
        break

print "Adivinaste!"






