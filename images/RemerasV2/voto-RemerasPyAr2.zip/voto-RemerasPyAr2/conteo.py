import sys, csv
from operator import itemgetter

votos = {}
for lin in csv.reader(open("votos.txt")):
    votos[lin[1]] = lin[2:]

conteo = {}
posics = range(0,6,2)

for vts in votos.values():
    for pos in posics:
        vot = vts[pos]
        ptj = int(vts[pos+1])
        if vot != "Sin voto":
            conteo[vot] = conteo.get(vot, 0) + ptj

largomax = max(len(x) for x in conteo)
for remera, cant in sorted(conteo.items(), key=itemgetter(1), reverse=True):
    print "%-*s %4d" % (largomax+3, remera, cant)
