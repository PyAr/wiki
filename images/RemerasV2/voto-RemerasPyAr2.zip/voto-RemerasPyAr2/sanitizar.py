import sys, csv

# levantamos los votos
arch = open("pyar-suscriptores.txt")
votos = set(x.strip() for x in arch)
arch.close()

# destino sanitizado
dest = csv.writer(open("votos.txt", "w"))

# filtramos
for nomarch in sys.argv[1:]:
    arch = csv.reader(open(nomarch))
    for lin in arch:
        if lin[1] in votos:
            dest.writerow(lin)
        else:
            print lin
    
