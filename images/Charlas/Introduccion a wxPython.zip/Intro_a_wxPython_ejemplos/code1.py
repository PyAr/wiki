#!/usr/bin/env python
import wx

if __name__ == '__main__':
    app = wx.App()
    frame = wx.Frame(None, wx.ID_ANY, "Hola Mundo")
    frame.Show()
    app.MainLoop()

