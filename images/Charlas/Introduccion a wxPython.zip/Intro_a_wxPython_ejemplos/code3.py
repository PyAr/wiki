#!/usr/bin/env python
# coding: utf-8

import wx

class MainWindow(wx.Frame):
    def __init__(self, parent, title):
        wx.Frame.__init__(self, parent, title=title, size=(640,480))
        
        self.CreateStatusBar()

        filemenu= wx.Menu()
        filemenu.Append(wx.ID_ABOUT, u'&Acerca De...', u'Información del Programa')
        filemenu.AppendSeparator()
        filemenu.Append(wx.ID_EXIT,u'&Salir', u'Salir del Programa')

        menuBar = wx.MenuBar()
        menuBar.Append(filemenu, u'&Archivo')
        self.SetMenuBar(menuBar)
        
        self.sizer_botones = wx.BoxSizer(wx.HORIZONTAL)
        self.buttons = []
        for i in range(0, 6):
            self.buttons.append(wx.Button(self, wx.ID_ANY, u'Botón &' + str(i)))
            self.sizer_botones.Add(self.buttons[i], proportion=1, flag=wx.EXPAND)

        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.txtNotes = wx.TextCtrl(self, style=wx.TE_MULTILINE)
        self.sizer_form = wx.GridSizer(rows=2, cols=3)
        for row in range(0, 2):
            self.sizer_form.AddMany((wx.StaticText(self, id=wx.ID_ANY, label=u'Texto Columna 1'), 
                                        wx.TextCtrl(self), wx.ComboBox(self)))
        self.sizer.Add(self.sizer_botones, proportion=2, flag=wx.EXPAND)
        self.sizer.Add(self.txtNotes, proportion=1, flag=wx.EXPAND)
        self.sizer.Add(self.sizer_form, proportion=0)
        self.SetSizer(self.sizer)


if __name__ == '__main__':
    app = wx.App()
    frame = MainWindow(None, u'Editor de Ejemplo')
    frame.Show()
    app.MainLoop()
