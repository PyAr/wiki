#!/usr/bin/python
# coding: utf-8

import  wx
import  wx.xrc as xrc


class EditorApp(wx.App):

    XRC_FILE = 'example.xrc'

    def OnInit(self):
        # Cargo el XRC y el frame principal
        self.res = xrc.XmlResource(EditorApp.XRC_FILE)
        self.frame = self.res.LoadFrame(None, 'MainWindow')
        # Obtengo la referencia al texto, útil
        self.txtTexto = xrc.XRCCTRL(self.frame, 'txtTexto')
        # Conecto los eventos
        self.frame.Bind(wx.EVT_MENU, self.OnNuevo,  id=xrc.XRCID('mnuNuevo'))
        self.frame.Bind(wx.EVT_MENU, self.OnAbrir,  id=xrc.XRCID('mnuAbrir'))
        self.frame.Bind(wx.EVT_MENU, self.OnGuardar,  id=xrc.XRCID('mnuGuardar'))
        self.frame.Bind(wx.EVT_MENU, self.OnSalir,  id=xrc.XRCID('mnuSalir'))
        self.frame.Show()
        return True

    def OnNuevo(self, event):
        # TODO: Preguntar si desea guardar los cambios con un Dialog
        self.txtTexto.Clear()

    def OnAbrir(self, event):
        filters = 'All files (*.*)|*.*|Text files (*.txt)|*.txt'
        dialog = wx.FileDialog(None, message=u'Abrir Archivo de Texto', wildcard=filters, style=wx.OPEN)
        if dialog.ShowModal() == wx.ID_OK:
            file_path = dialog.GetPath()
            self.txtTexto.SetValue(open(file_path, 'r').read())
        dialog.Destroy()

    def OnGuardar(self, event):
        dialog = wx.FileDialog(None, message=u'Guardar Archivo de Texto', style=wx.SAVE|wx.FD_OVERWRITE_PROMPT)
        if dialog.ShowModal() == wx.ID_OK:
            file_path = dialog.GetPath()
            open(file_path, 'w').write(self.txtTexto.GetValue())
        dialog.Destroy()

    def OnSalir(self, event):
        self.frame.Close()


if __name__ == '__main__':
    app = EditorApp()
    app.MainLoop()
