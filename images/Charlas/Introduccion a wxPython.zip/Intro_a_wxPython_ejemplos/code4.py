#!/usr/bin/env python
# coding: utf-8

import wx

class MainWindow(wx.Frame):
    def __init__(self, parent, title):
        wx.Frame.__init__(self, parent, title=title, size=(300,150))
        
        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.sizer_form = wx.GridSizer(rows=2, cols=2)
        self.txtNombre = wx.TextCtrl(self)
        self.txtApellido = wx.TextCtrl(self)
        self.sizer_form.Add(wx.StaticText(self, wx.ID_ANY, label=u'Nombre'))
        self.sizer_form.Add(self.txtNombre, flag=wx.EXPAND)
        self.sizer_form.Add(wx.StaticText(self, wx.ID_ANY, label=u'Apellido'))
        self.sizer_form.Add(self.txtApellido, flag=wx.EXPAND)

        self.txtNombre.Bind(wx.EVT_KEY_UP, self.OnTxtNombre)
        self.txtApellido.Bind(wx.EVT_KEY_UP, self.OnTxtApellido)
        
        self.sizer_botones = wx.BoxSizer(wx.HORIZONTAL)
        self.btnAceptar = wx.Button(self, wx.ID_ANY, u'&Aceptar')
        self.btnCancelar = wx.Button(self, wx.ID_ANY, u'&Cancelar')
        self.sizer_botones.Add(self.btnAceptar, proportion=0)
        self.sizer_botones.Add(self.btnCancelar, proportion=0)
        self.btnAceptar.Bind(wx.EVT_BUTTON, self.OnAceptar)
        self.btnCancelar.Bind(wx.EVT_BUTTON, self.OnCancelar)

        self.sizer.Add(self.sizer_form, flag=wx.EXPAND|wx.ALIGN_CENTER)
        self.sizer.Add(self.sizer_botones, flag=wx.ALIGN_CENTER)
        self.SetSizer(self.sizer)

    def OnAceptar(self, event):
        dlg = wx.MessageDialog(self, u'¡El usuario hizo click en Aceptar!', u'Ejemplo', wx.OK)
        dlg.ShowModal()
        dlg.Destroy()

    def OnCancelar(self, event):
        self.Close()

    def OnTxtNombre(self, event):
        keycode = event.GetKeyCode()
        print u'Tecleó en Nombre: ' + str(keycode)
        if keycode == wx.WXK_TAB:
            print 'Tab!'

    def OnTxtApellido(self, event):
        keycode = event.GetKeyCode()
        print u'Tecleó en Apellido :' + str(keycode)
        if keycode == wx.WXK_F1:
            print 'F1!'

if __name__ == '__main__':
    app = wx.App()
    frame = MainWindow(None, u'Aplicación de Ejemplo')
    frame.Center()
    frame.Show()
    app.MainLoop()
