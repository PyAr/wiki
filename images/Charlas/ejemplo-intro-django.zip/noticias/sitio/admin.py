from noticias.sitio.models import Noticia
from django.contrib import admin

admin.site.register(Noticia)

