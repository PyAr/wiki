#!python
# -*- coding: iso-8859-1 -*-

"Ejemplo Servidor COM para interface con Windows"

__author__ = "Mariano Reingart (mariano@nsis.com.ar)"
__copyright__ = "Copyright (C) 2009 Mariano Reingart"
__license__ = "LGPL 3.0"
__version__ = "0.00"

import sys

class MiMiniInterpretePython:
    _public_methods_ = ['Evaluar']    # M�todos a exportar por el servidor COM
    _public_attrs_ = ['Version']      # Atributos a exportar por el servidor COM
    _readonly_attrs_ = _public_attrs_ # Atributos de solo lectura
    _reg_progid_ = "MiMiniInterpretePython"   # Nombre para Crear el Objeto COM
    # NUNCA copiar el siguiente ID 
    # Usar "print pythoncom.CreateGuid()" para crear uno nuevo
    _reg_clsid_ = "{ECDDA31C-2999-4C77-9778-DDF75FBF81FC}"

    def __init__(self):
        # constructor, setear atributos:
        self.Version = sys.version
    
    def Evaluar(self, expresion):
        "Evalua una expresi�n python y devuelve su resultado"
        return str(eval(expresion))
    
 
# Agregar c�digo para que si este script es ejecutado por linea de comando,
# por Python.exe, se auto-registre
if __name__=='__main__':
    import win32com.server.register
    win32com.server.register.UseCommandLine(MiMiniInterpretePython)

