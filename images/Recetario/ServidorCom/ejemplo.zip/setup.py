#!python
# -*- coding: iso-8859-1 -*-

"Ejemplo Directivas Instalaci�n para Servidor COM (interface con Windows)"

__author__ = "Mariano Reingart (mariano@nsis.com.ar)"
__copyright__ = "Copyright (C) 2009 Mariano Reingart"
__license__ = "LGPL 3.0"
__version__ = "0.00"

from distutils.core import setup
import py2exe

setup( name = "MiServidorCOM",
    com_server = ["miservidorcom"],
       )
