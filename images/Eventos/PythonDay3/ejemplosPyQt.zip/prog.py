import sys

from PyQt4 import QtGui, uic

if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    m = uic.loadUi('./main.ui')
    m.show()

    sys.exit(app.exec_())
