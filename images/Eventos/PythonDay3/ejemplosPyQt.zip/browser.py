import sys, re

from PyQt4 import QtGui, QtCore, QtWebKit

class Browser(QtGui.QWidget):
    
    def __init__(self):
        QtGui.QWidget.__init__(self)
        self.setWindowTitle('Python Day Browser')
        
        v_box = QtGui.QVBoxLayout(self)
        #Navigation Bar
        self.back = QtGui.QPushButton(self.style().standardIcon(QtGui.QStyle.SP_ArrowLeft), '')
        self.forward = QtGui.QPushButton(self.style().standardIcon(QtGui.QStyle.SP_ArrowRight), '')
        self.reload = QtGui.QPushButton(self.style().standardIcon(QtGui.QStyle.SP_BrowserReload), '')
        self.stop = QtGui.QPushButton(self.style().standardIcon(QtGui.QStyle.SP_BrowserStop), '')
        self.btnUrl = QtGui.QPushButton(self.style().standardIcon(QtGui.QStyle.SP_DialogOkButton), '')
        self.url = QtGui.QLineEdit('')
        h_bar = QtGui.QHBoxLayout()
        h_bar.addWidget(self.back)
        h_bar.addWidget(self.forward)
        h_bar.addWidget(self.reload)
        h_bar.addWidget(self.stop)
        h_bar.addWidget(self.url)
        h_bar.addWidget(self.btnUrl)
        #Web View
        self.web = QtWebKit.QWebView()
        self.web.load(QtCore.QUrl('http://python.org.ar'))
        #Status
        self.status = QtGui.QStatusBar()
        self.status.addWidget(QtGui.QLabel('Loading...'))
        self.progress = QtGui.QProgressBar()
        self.status.addWidget(self.progress)
        #Shortcut
        self.short = QtGui.QShortcut(QtGui.QKeySequence(QtCore.Qt.CTRL + QtCore.Qt.Key_J), self.url)
        
        #Add
        v_box.addLayout(h_bar)
        v_box.addWidget(self.web)
        v_box.addWidget(self.status)
        
        #Signal -> Slot
        self.connect(self.back, QtCore.SIGNAL("clicked()"), self.web.back)
        self.connect(self.forward, QtCore.SIGNAL("clicked()"), self.web.forward)
        self.connect(self.reload, QtCore.SIGNAL("clicked()"), self.web.reload)
        self.connect(self.stop, QtCore.SIGNAL("clicked()"), self.web.stop)
        self.connect(self.btnUrl, QtCore.SIGNAL("clicked()"), self.do_search)
        self.connect(self.url, QtCore.SIGNAL("returnPressed()"), self.do_search)
        self.connect(self.web, QtCore.SIGNAL("loadProgress(int)"), self.load_progress)
        self.connect(self.web, QtCore.SIGNAL("loadFinished(bool)"), self.load_complete)
        self.connect(self.web, QtCore.SIGNAL("loadStarted()"), self.status.show)
        self.connect(self.short, QtCore.SIGNAL("activated()"), self.url.setFocus)
        
    def load_progress(self, val):
        self.progress.setValue(val)
        
    def open_url(self, link):
        self.web.load(QtCore.QUrl(link))
        
    def do_search(self):
        link = str(self.url.text())
        pat = re.compile('(.+)\\.(.+)')
        patHttp = re.compile('^http://')
        if pat.match(link) and not patHttp.match(link):
            link = 'http://' + link
        elif not pat.match(link):
            link = 'http://google.com.ar/search?q=' + link.replace(' ', '+')
        self.open_url(link)
        
    def load_complete(self):
        self.url.setText(self.web.url().toString())
        self.status.hide()
        self.web.setFocus()
        

app = QtGui.QApplication(sys.argv)
b = Browser()
b.show()

sys.exit(app.exec_())
