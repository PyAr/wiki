#! /usr/bin/env python
# coding: utf-8
# $Rev: 3983 $

# GLADE IN ACTION
import pygtk
pygtk.require('2.0')
import gtk, gtk.glade

class MyApp(object):
    """A very useful GUI."""

    def __init__(self):
        self.w_tree = gtk.glade.XML('simple.glade')

        self.entry = self.w_tree.get_widget('entry')
        self.ok_button = self.w_tree.get_widget('ok_button')
        self.cancel_button = self.w_tree.get_widget('cancel_button')

        self.window = self.w_tree.get_widget('window')
        self.window.connect('delete-event', self.main_quit)

        # glade sets widgets.visible to True automatically
        # self.window.show_all()

    def main(self):
        """Let GTK do its job. We lost program control here!."""
        gtk.main()

    def main_quit(self, *args, **kwargs):
        """GTK, thank you, bye!"""
        gtk.main_quit()

if __name__ == "__main__":
    app = MyApp()
    app.main()
