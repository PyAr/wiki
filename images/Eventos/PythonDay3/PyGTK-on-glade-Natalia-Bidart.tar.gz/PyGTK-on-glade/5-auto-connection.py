#! /usr/bin/env python
# coding: utf-8
# $Rev: 3983 $

# AUTO CONNECTION
import pygtk
pygtk.require('2.0')
import gtk, gtk.glade
import inspect

class MyApp(object):
    """A very useful GUI."""

    def __init__(self):
        self.w_tree = gtk.glade.XML('simple.glade')

        self.entry = self.w_tree.get_widget('entry')
        self.ok_button = self.w_tree.get_widget('ok_button')
        self.cancel_button = self.w_tree.get_widget('cancel_button')

        self.window = self.w_tree.get_widget('window')

        d = dict(inspect.getmembers(self))
        self.w_tree.signal_autoconnect(d)

    def on_entry_activate(self, widget, data=None):
        """Print the entered value on stdou and clear the text entry."""
        value = self.entry.get_text()
        print('Value entered: ' + value)
        self.entry.set_text('')

    def on_ok_button_clicked(self, widget, data=None):
        """Print to stdout a message."""
        print('Ok button clicked!')

    def on_cancel_button_clicked(self, widget, data=None):
        """Print to stdout a message."""
        print('Cancel button clicked!')

    def main(self):
        """Let GTK do its job. We lost program control here!."""
        gtk.main()

    def main_quit(self, *args, **kwargs):
        """GTK, thank you, bye!"""
        gtk.main_quit()

if __name__ == "__main__":
    app = MyApp()
    app.main()
