import sys
import time
import gdata.spreadsheet.service

from settings import USER, PASSWORD

spreadsheet_key = 'tVASiTbq7PTEl5ufshZ415Q'
worksheet_id = 'od6'

def update_weight(weight):
    """Update weight spreadsheet."""
    # get service instance
    spr_client = gdata.spreadsheet.service.SpreadsheetsService()
    spr_client.email = USER
    spr_client.password = PASSWORD
    spr_client.ProgrammaticLogin()

    # prepare the dictionary to write
    data_dict = {}
    data_dict['fecha'] = time.strftime('%m/%d/%Y')
    data_dict['hora'] = time.strftime('%H:%M:%S')
    data_dict['peso'] = weight

    entry = spr_client.InsertRow(data_dict, spreadsheet_key, worksheet_id)
    if isinstance(entry, gdata.spreadsheet.SpreadsheetsList):
        print "Insert row succeeded."
    else:
        print "Insert row failed."

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print "Usage: %s <weight>" % sys.argv[0]
        exit(1)

    weight = sys.argv[1]
    update_weight(weight)
