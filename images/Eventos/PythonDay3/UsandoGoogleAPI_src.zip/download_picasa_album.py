# -*- coding: utf-8 -*-

import sys
import urllib2

import gdata.photos.service

def list_albums_from_user(username):
    """Print the info of the user albums."""
    photo_service = gdata.photos.service.PhotosService()
    albums = photo_service.GetUserFeed(user=username)
    for album in albums.entry:
        print 'title: %s, number of photos: %s, id: %s' % (album.title.text,
        album.numphotos.text, album.gphoto_id.text)

def download_album_from_user(username, album, dest="."):
    """Download the photos from the album given."""
    photo_service = gdata.photos.service.PhotosService()
    feed_url = '/data/feed/api/user/%s/albumid/%s?kind=photo' % (username, album)
    photos = photo_service.GetFeed(feed_url).entry
    for photo_entry in photos:
        print "Downloading... %s" % photo_entry.title.text
        photo = urllib2.urlopen(photo_entry.content.src)
        photo_data = photo.read()
        file_dest = dest + "/" + photo_entry.title.text
        f = open(file_dest, 'w')
        f.write(photo_data)
        f.close()


if __name__ == '__main__':
    if len(sys.argv) == 2:
        username = sys.argv[1]
        list_albums_from_user(username)
    elif len(sys.argv) == 3:
        username = sys.argv[1]
        album = sys.argv[2]
        download_album_from_user(username, album)
    else:
        print "Usage: %s <username> [album_id]" % sys.argv[0]
        exit(1)
