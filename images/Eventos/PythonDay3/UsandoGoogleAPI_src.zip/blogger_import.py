# -*- coding: utf-8 -*-

import sys

from gdata import service
from settings import USER, PASSWORD

class BloggerImport:
    """Blogger posts and comments importer."""

    def __init__(self, username, password):
        # generic service instance
        self.blogger_service = service.GDataService(username, password)
        self.blogger_service.service = 'blogger'
        self.blogger_service.account_type = 'GOOGLE'
        self.blogger_service.server = 'www.blogger.com'
        self.blogger_service.ProgrammaticLogin()
        self.blog_id = self._get_first_blog_id()

    def _get_first_blog_id(self):
        """Return the first blog id found."""
        query = service.Query()
        query.feed = '/feeds/default/blogs'
        feed = self.blogger_service.Get(query.ToUri())

        blog_id = feed.entry[0].GetSelfLink().href.split("/")[-1]
        return blog_id

    def _get_all_posts_feed(self):
        """Return the feed for all posts."""
        feed_url = '/feeds/%s/posts/default?max-results=500' %  self.blog_id
        feed = self.blogger_service.GetFeed(feed_url)
        return feed

    def import_posts(self):
        """Get the information of the posts in the blog."""
        feed = self._get_all_posts_feed()
        for entry in feed.entry:
            author = entry.author[0].name.text
            post_id = entry.GetSelfLink().href.split("/")[-1]
            tags = ','.join([t.term for t in entry.category])

            print "Post Title:", entry.title.text
            print "Published:", entry.published.text
            print "Tags:", tags
            self._import_comments(post_id)
            print "------------------------"

    def _import_comments(self, post_id):
        """Get the information for the comments in the given post."""
        feed_url = '/feeds/%s/%s/comments/default' % (self.blog_id, post_id)
        try:
            feed = self.blogger_service.Get(feed_url)
            print "Comments:", len(feed.entry)
        except:
            print 'No comments'


if __name__ == '__main__':
    importer = BloggerImport(USER, PASSWORD)
    importer.import_posts()
