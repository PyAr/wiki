# -*- coding: utf-8 -*-

import sys

import gdata.youtube
import gdata.youtube.service

def PrintEntryDetails(entry):
    """Print the entry details."""
    print 'Video title: %s' % entry.media.title.text
    print 'Video published on: %s ' % entry.published.text
    print 'Video description: %s' % entry.media.description.text
    print 'Video category: %s' % entry.media.category[0].text
    print 'Video tags: %s' % entry.media.keywords.text
    print 'Video watch page: %s' % entry.media.player.url
    print 'Video duration: %s' % entry.media.duration.seconds

    # non entry.media attributes
    print 'Video view count: %s' % entry.statistics.view_count
    if entry.rating: print 'Video rating: %s' % entry.rating.average
    print "------------------------"

def PrintVideoFeed(feed):
    """Print the details for each entry in the feed."""
    for entry in feed.entry:
        PrintEntryDetails(entry)

def SearchAndPrint(search_terms):
    """Search youtube videos and print the results information."""
    yt_service = gdata.youtube.service.YouTubeService()
    query = gdata.youtube.service.YouTubeVideoQuery()
    query.vq = search_terms     # search terms
    query.orderby = 'viewCount' # order by: relevance|viewCount|published|rating
    query.racy = 'include'      # restricted content: include|exclude
    query.max_results = 3       # top 3
                                # other params: author, format, time
    feed = yt_service.YouTubeQuery(query)
    PrintVideoFeed(feed)

if __name__ == '__main__':
    search_terms = ''.join(sys.argv[1:])
    if not search_terms:
        print 'Missing search terms'
        exit(1)

    SearchAndPrint(search_terms)
